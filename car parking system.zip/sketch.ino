#include <LiquidCrystal.h>
#include <Servo.h>

const byte IR_ACTIVE_STATE = LOW;

const byte LCD_RS = 2;
const byte LCD_EN = 3;
const byte LCD_D4 = 4;
const byte LCD_D5 = 5;
const byte LCD_D6 = 6;
const byte LCD_D7 = 7;
const byte US_TRIG = 8;
const byte US_ECHO = 9;
const byte SERVO_PIN = 10;
const byte IR_PIN = 11;
const byte PIR_PIN = 12;
const byte PARK_LIGHT_PIN = 13;
const byte LM35_PIN = A0;
const byte GREEN_LED_PIN = A1;
const byte RED_LED_PIN = A2;
const byte LDR_PIN = A3;

const int FULL_DISTANCE_CM = 15;
const int ENTRANCE_TIMEOUT_MS = 3000;
const int DARK_LEVEL = 450;

LiquidCrystal lcd(LCD_RS, LCD_EN, LCD_D4, LCD_D5, LCD_D6, LCD_D7);
Servo gateServo;

bool gateIsOpen = false;
bool previousIrDetected = false;
unsigned long gateOpenedAt = 0;
unsigned long lastDisplayAt = 0;
bool displayPage = false;

float readDistanceCm() {
  digitalWrite(US_TRIG, LOW);
  delayMicroseconds(3);
  digitalWrite(US_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(US_TRIG, LOW);
  unsigned long duration = pulseIn(US_ECHO, HIGH, 30000UL);
  if (duration == 0) return 400.0; 
  return duration * 0.0343 / 2.0;
}

float readTemperatureC() {
  int raw = analogRead(LM35_PIN);
  float voltage = raw * (5.0 / 1023.0);
  return voltage * 100.0;
}

void setup() {
  pinMode(US_TRIG, OUTPUT);
  pinMode(US_ECHO, INPUT);
  pinMode(IR_PIN, INPUT_PULLUP);
  pinMode(PIR_PIN, INPUT);
  pinMode(PARK_LIGHT_PIN, OUTPUT);
  pinMode(GREEN_LED_PIN, OUTPUT);
  pinMode(RED_LED_PIN, OUTPUT);
  gateServo.attach(SERVO_PIN);
  gateServo.write(0);
  lcd.begin(16, 2);
  lcd.clear();
  lcd.print("Car Parking Sys");
  delay(1200);
}

void loop() {
  float distance = readDistanceCm();
  bool occupied = distance < FULL_DISTANCE_CM;
  bool irDetected = digitalRead(IR_PIN) == IR_ACTIVE_STATE;
  bool motionDetected = digitalRead(PIR_PIN) == HIGH;
  int lightLevel = analogRead(LDR_PIN);
  float temperature = readTemperatureC();

  if (irDetected && !previousIrDetected && !occupied && !gateIsOpen) {
    gateServo.write(90);
    gateIsOpen = true;
    gateOpenedAt = millis();
  }
  previousIrDetected = irDetected;

  if (gateIsOpen && millis() - gateOpenedAt >= ENTRANCE_TIMEOUT_MS) {
    gateServo.write(0);
    gateIsOpen = false;
  }

  digitalWrite(GREEN_LED_PIN, occupied ? LOW : HIGH);
  digitalWrite(RED_LED_PIN, occupied ? HIGH : LOW);
  digitalWrite(PARK_LIGHT_PIN, lightLevel < DARK_LEVEL ? HIGH : LOW);

  if (millis() - lastDisplayAt >= 2000) {
    lastDisplayAt = millis();
    displayPage = !displayPage;
    lcd.clear();
    if (!displayPage) {
      lcd.setCursor(0, 0);
      lcd.print(occupied ? "Parking: FULL" : "Parking: FREE");
      lcd.setCursor(0, 1);
      lcd.print("Dist:");
      if (distance >= 400.0) lcd.print("---");
      else { lcd.print((int)distance); lcd.print("cm"); }
      lcd.print(gateIsOpen ? " Gate:OPEN" : " Gate:CLOSE");
    } else {
      lcd.setCursor(0, 0);
      lcd.print("Temp:");
      lcd.print(temperature, 1);
      lcd.print((char)223);
      lcd.print("C");
      lcd.setCursor(0, 1);
      lcd.print("Motion:");
      lcd.print(motionDetected ? "YES" : "NO ");
      lcd.print(" L:");
      lcd.print(lightLevel < DARK_LEVEL ? "ON " : "OFF");
    }
  }

  delay(60);
}
